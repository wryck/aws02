import json
import psycopg2

def lambda_handler(event, context):
    conn = psycopg2.connect(
        host="taskdb2.cjtlj43kxle3.us-east-1.rds.amazonaws.com",
        database="taskdb2",
        user="postgres",
        password="ZYBEMb0m+"
    )
    cur = conn.cursor()

    if event['httpMethod'] == 'POST':
        data = json.loads(event['body'])
        cur.execute("INSERT INTO tasks (title) VALUES (%s)", (data['title'],))
        conn.commit()
        return {
            'statusCode': 201,
            'body': json.dumps('Task created successfully')
        }
    
    elif event['httpMethod'] == 'GET':
        cur.execute("SELECT * FROM tasks")
        tasks = cur.fetchall()
        return {
            'statusCode': 200,
            'body': json.dumps(tasks)
        }

    cur.close()
    conn.close()
