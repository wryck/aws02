const { Client } = require('pg');

exports.handler = async (event) => {
    const client = new Client({
        host: 'taskdb.cjtlj43kxle3.us-east-1.rds.amazonaws.com',
        user: 'competidor',
        password: 'ZYBEMb0m+',
        database: 'taskdb',
        port: 5432,
    });

    await client.connect();

    let response;
    try {
        if (event.httpMethod === 'POST') {
            const data = JSON.parse(event.body);
            const res = await client.query('INSERT INTO tasks (title) VALUES ($1) RETURNING *', [data.title]);
            response = {
                statusCode: 201,
                body: JSON.stringify(res.rows[0]),
            };
        } else if (event.httpMethod === 'GET') {
            const res = await client.query('SELECT * FROM tasks');
            response = {
                statusCode: 200,
                body: JSON.stringify(res.rows),
            };
        }
    } catch (err) {
        console.error(err);
        response = {
            statusCode: 500,
            body: JSON.stringify('Internal Server Error'),
        };
    } finally {
        await client.end();
    }

    return response;
};

